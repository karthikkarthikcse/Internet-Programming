// --------------------------------
// Default Jobs
// --------------------------------

let jobs = JSON.parse(localStorage.getItem("jobs"));

if (!jobs) {

    jobs = [

        {
            id: 1,
            title: "Frontend Developer",
            company: "Tech Solutions",
            location: "Chennai",
            salary: "₹4 - ₹6 LPA",
            type: "Full Time",
            description:
            "Develop responsive websites using HTML, CSS and JavaScript."
        },

        {
            id: 2,
            title: "Java Developer",
            company: "Infosys",
            location: "Bangalore",
            salary: "₹5 - ₹8 LPA",
            type: "Full Time",
            description:
            "Develop and maintain Java based enterprise applications."
        },

        {
            id: 3,
            title: "Data Science Intern",
            company: "DataTech",
            location: "Remote",
            salary: "₹15,000 / Month",
            type: "Internship",
            description:
            "Work with Python, Pandas and Machine Learning projects."
        },

        {
            id: 4,
            title: "UI/UX Designer",
            company: "Creative Studio",
            location: "Coimbatore",
            salary: "₹3 - ₹5 LPA",
            type: "Full Time",
            description:
            "Design modern and user-friendly web and mobile interfaces."
        }

    ];

    localStorage.setItem(
        "jobs",
        JSON.stringify(jobs)
    );
}


// --------------------------------
// Display Jobs
// --------------------------------

function displayJobs() {

    let container =
        document.getElementById("jobList");

    if (!container) return;

    let search =
        document.getElementById("jobSearch")
        .value
        .toLowerCase();

    let filteredJobs =
        jobs.filter(function(job) {

            return (
                job.title.toLowerCase().includes(search) ||
                job.company.toLowerCase().includes(search) ||
                job.location.toLowerCase().includes(search)
            );

        });

    container.innerHTML = "";

    if (filteredJobs.length === 0) {

        container.innerHTML =
        "<h3>No jobs found.</h3>";

        return;
    }

    filteredJobs.forEach(function(job) {

        container.innerHTML += `

            <div class="job-card">

                <h3>${job.title}</h3>

                <p><strong>Company:</strong>
                ${job.company}</p>

                <p><strong>Location:</strong>
                ${job.location}</p>

                <p><strong>Salary:</strong>
                ${job.salary}</p>

                <p><strong>Type:</strong>
                ${job.type}</p>

                <p>
                ${job.description}
                </p>

                <button onclick="applyJob(${job.id})">
                    Apply Now
                </button>

            </div>

        `;

    });
}


// --------------------------------
// Latest Jobs
// --------------------------------

function displayLatestJobs() {

    let container =
        document.getElementById("latestJobs");

    if (!container) return;

    container.innerHTML = "";

    jobs.slice(-3).reverse().forEach(function(job) {

        container.innerHTML += `

            <div class="job-card">

                <h3>${job.title}</h3>

                <p>
                <strong>${job.company}</strong>
                </p>

                <p>📍 ${job.location}</p>

                <p>💰 ${job.salary}</p>

                <button onclick="applyJob(${job.id})">
                    Apply Now
                </button>

            </div>

        `;

    });
}


// --------------------------------
// Apply for Job
// --------------------------------

function applyJob(jobId) {

    let job =
        jobs.find(function(j) {
            return j.id === jobId;
        });

    let name =
        prompt("Enter your full name:");

    if (!name) return;

    let email =
        prompt("Enter your email:");

    if (!email) return;

    let applications =
        JSON.parse(
            localStorage.getItem("applications")
        ) || [];

    applications.push({

        id: Date.now(),

        jobId: job.id,

        jobTitle: job.title,

        company: job.company,

        applicantName: name,

        applicantEmail: email,

        date: new Date().toLocaleDateString(),

        status: "Submitted"

    });

    localStorage.setItem(
        "applications",
        JSON.stringify(applications)
    );

    alert(
        "Application submitted successfully!"
    );
}


// --------------------------------
// Display Applications
// --------------------------------

function displayApplications() {

    let container =
        document.getElementById(
            "applicationsList"
        );

    if (!container) return;

    let applications =
        JSON.parse(
            localStorage.getItem("applications")
        ) || [];

    container.innerHTML = "";

    if (applications.length === 0) {

        container.innerHTML =
        "<h3>No applications submitted yet.</h3>";

        return;
    }

    applications.reverse().forEach(function(app) {

        container.innerHTML += `

            <div class="application-card">

                <h3>${app.jobTitle}</h3>

                <p>
                <strong>Company:</strong>
                ${app.company}
                </p>

                <p>
                <strong>Applicant:</strong>
                ${app.applicantName}
                </p>

                <p>
                <strong>Email:</strong>
                ${app.applicantEmail}
                </p>

                <p>
                <strong>Date:</strong>
                ${app.date}
                </p>

                <p>
                <strong>Status:</strong>
                ${app.status}
                </p>

            </div>

        `;

    });
}


// --------------------------------
// Register User
// --------------------------------

function registerUser(event) {

    event.preventDefault();

    let name =
        document.getElementById("name").value;

    let email =
        document.getElementById("email").value;

    let password =
        document.getElementById("password").value;

    let role =
        document.getElementById("role").value;

    let users =
        JSON.parse(
            localStorage.getItem("users")
        ) || [];

    users.push({

        name: name,

        email: email,

        password: password,

        role: role

    });

    localStorage.setItem(
        "users",
        JSON.stringify(users)
    );

    alert(
        "Registration successful!"
    );

    event.target.reset();

}


// --------------------------------
// Post New Job
// --------------------------------

function postJob(event) {

    event.preventDefault();

    let newJob = {

        id: Date.now(),

        title:
        document.getElementById(
            "jobTitle"
        ).value,

        company:
        document.getElementById(
            "company"
        ).value,

        location:
        document.getElementById(
            "location"
        ).value,

        salary:
        document.getElementById(
            "salary"
        ).value,

        type:
        document.getElementById(
            "jobType"
        ).value,

        description:
        document.getElementById(
            "description"
        ).value

    };

    jobs.push(newJob);

    localStorage.setItem(
        "jobs",
        JSON.stringify(jobs)
    );

    alert(
        "Job posted successfully!"
    );

    event.target.reset();

}


// --------------------------------
// Home Search
// --------------------------------

function searchHomeJobs() {

    let search =
        document.getElementById(
            "homeSearch"
        ).value;

    localStorage.setItem(
        "jobSearch",
        search
    );

    window.location.href =
        "jobs.html";

}


// --------------------------------
// Page Load
// --------------------------------

displayLatestJobs();